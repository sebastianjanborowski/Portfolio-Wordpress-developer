<?php
/**
 * Newsletter: zapis emaili do DB + panel w kokpicie + shortcode formularza
 * Wklej do functions.php motywu potomnego (zalecane) albo do własnej wtyczki.
 */

defined('ABSPATH') || exit;

global $bydlo_newsletter_db_version;
$bydlo_newsletter_db_version = '1.0.0';

/** 1) Tworzenie tabeli */
function bydlo_newsletter_install_table() {
  global $wpdb;
  $table = $wpdb->prefix . 'newsletter_signups';
  $charset = $wpdb->get_charset_collate();

  require_once ABSPATH . 'wp-admin/includes/upgrade.php';

  $sql = "CREATE TABLE {$table} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(190) NOT NULL,
    ip VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY email_unique (email)
  ) {$charset};";

  dbDelta($sql);

  update_option('bydlo_newsletter_db_version', '1.0.0');
}

/**
 * UWAGA: bezpieczniejsze niż register_activation_hook w functions.php:
 * tabela stworzy się przy pierwszym wejściu, gdy nie istnieje.
 */
add_action('init', function () {
  global $wpdb;
  $table = $wpdb->prefix . 'newsletter_signups';
  $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
  if ($exists !== $table) {
    bydlo_newsletter_install_table();
  }
});

/** 2) Zapis e-maila */
function bydlo_newsletter_add_email($email) {
  global $wpdb;
  $table = $wpdb->prefix . 'newsletter_signups';

  $email = sanitize_email($email);
  if (!$email || !is_email($email)) {
    return new WP_Error('invalid_email', 'Niepoprawny adres e-mail.');
  }

  $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : null;
  $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : null;

  $inserted = $wpdb->insert(
    $table,
    [
      'email' => $email,
      'ip' => $ip,
      'user_agent' => $ua,
      'created_at' => current_time('mysql'),
    ],
    ['%s','%s','%s','%s']
  );

  if ($inserted === false) {
    // najczęściej duplikat (unique)
    $existing = $wpdb->get_var($wpdb->prepare("SELECT email FROM {$table} WHERE email = %s", $email));
    if ($existing) {
      return new WP_Error('duplicate', 'Ten e-mail jest już zapisany.');
    }
    return new WP_Error('db_error', 'Błąd zapisu do bazy.');
  }

  return true;
}

/** 3) Shortcode formularza: [newsletter_form] */
add_shortcode('newsletter_form', function ($atts) {
  $atts = shortcode_atts([
    'placeholder' => 'Wpisz swój e-mail',
    'button' => 'Zapisz się',
  ], $atts);

  $msg = '';
  $msg_type = '';

  if (!empty($_POST['bydlo_newsletter_submit']) && isset($_POST['bydlo_newsletter_nonce'])) {
    if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['bydlo_newsletter_nonce'])), 'bydlo_newsletter')) {
      $email = isset($_POST['bydlo_newsletter_email']) ? wp_unslash($_POST['bydlo_newsletter_email']) : '';
      $result = bydlo_newsletter_add_email($email);

      if ($result === true) {
        $msg = 'Zapisano. Dziękujemy.';
        $msg_type = 'success';
      } else {
        $msg = $result->get_error_message();
        $msg_type = 'error';
      }
    } else {
      $msg = 'Błąd zabezpieczenia formularza.';
      $msg_type = 'error';
    }
  }

  ob_start(); ?>
    <form method="post" class="holistic-footer-newsletter">
      <?php wp_nonce_field('bydlo_newsletter', 'bydlo_newsletter_nonce'); ?>
      <input
        type="email"
        name="bydlo_newsletter_email"
        required
        placeholder="<?php echo esc_attr($atts['placeholder']); ?>"
      >
      <button type="submit" name="bydlo_newsletter_submit" value="1" style="padding:10px 14px;">
        <?php echo esc_html($atts['button']); ?>
      </button>

      <?php if ($msg): ?>
        <div style="width:100%;margin-top:6px;">
          <strong><?php echo esc_html($msg); ?></strong>
        </div>
      <?php endif; ?>
    </form>
  <?php
  return ob_get_clean();
});

/** 4) Strona w kokpicie: Newsletter */
add_action('admin_menu', function () {
  add_menu_page(
    'Newsletter',
    'Newsletter',
    'manage_options',
    'bydlo-newsletter',
    'bydlo_newsletter_admin_page',
    'dashicons-email-alt2',
    26
  );
});

function bydlo_newsletter_admin_page() {
  if (!current_user_can('manage_options')) return;

  global $wpdb;
  $table = $wpdb->prefix . 'newsletter_signups';

  // Export CSV
  if (isset($_GET['bydlo_newsletter_export']) && $_GET['bydlo_newsletter_export'] === '1') {
    check_admin_referer('bydlo_newsletter_export');

    $rows = $wpdb->get_results("SELECT email, ip, created_at FROM {$table} ORDER BY id DESC", ARRAY_A);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=newsletter-emails.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['email', 'ip', 'created_at']);
    foreach ($rows as $r) {
      fputcsv($out, [$r['email'], $r['ip'], $r['created_at']]);
    }
    fclose($out);
    exit;
  }

  // Pagination
  $per_page = 50;
  $paged = max(1, (int)($_GET['paged'] ?? 1));
  $offset = ($paged - 1) * $per_page;

  $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
  $rows = $wpdb->get_results(
    $wpdb->prepare("SELECT id, email, ip, created_at FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset),
    ARRAY_A
  );

  $total_pages = max(1, (int)ceil($total / $per_page));

  echo '<div class="wrap">';
  echo '<h1>Newsletter – zapisane e-maile</h1>';

  echo '<p>';
  echo 'Łącznie: <strong>' . esc_html($total) . '</strong> ';
  echo ' | ';
  echo '<a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=bydlo-newsletter&bydlo_newsletter_export=1'), 'bydlo_newsletter_export')) . '">Eksport CSV</a>';
  echo '</p>';

  echo '<table class="widefat striped">';
  echo '<thead><tr><th>ID</th><th>E-mail</th><th>IP</th><th>Data</th></tr></thead><tbody>';

  if (!$rows) {
    echo '<tr><td colspan="4">Brak zapisów.</td></tr>';
  } else {
    foreach ($rows as $r) {
      echo '<tr>';
      echo '<td>' . esc_html($r['id']) . '</td>';
      echo '<td><strong>' . esc_html($r['email']) . '</strong></td>';
      echo '<td>' . esc_html($r['ip'] ?: '-') . '</td>';
      echo '<td>' . esc_html($r['created_at']) . '</td>';
      echo '</tr>';
    }
  }

  echo '</tbody></table>';

  // prosta paginacja
  if ($total_pages > 1) {
    echo '<p style="margin-top:12px;">';
    for ($i = 1; $i <= $total_pages; $i++) {
      $url = admin_url('admin.php?page=bydlo-newsletter&paged=' . $i);
      if ($i === $paged) {
        echo '<strong style="margin-right:8px;">' . $i . '</strong>';
      } else {
        echo '<a style="margin-right:8px;" href="' . esc_url($url) . '">' . $i . '</a>';
      }
    }
    echo '</p>';
  }

  echo '</div>';
}