<?php
defined('ABSPATH') || exit;

get_header('shop');
?>

<style>
/* =========================================================
   SINGLE PRODUCT – Holistic Beauty (FULL)
   ========================================================= */

:root{
  --hb-green:#1f5a3a;
  --hb-green-2:#14412a;
  --hb-gold:#c9a548;
  --hb-paper: rgba(255,255,255,.82);
  --hb-paper-2: rgba(255,255,255,.55);
  --hb-border: rgba(0,0,0,.08);
  --hb-shadow: 0 14px 40px rgba(0,0,0,.10);
  --hb-radius: 22px;
  --hb-radius-2: 18px;
  --hb-radius-3: 14px;
}

/* wrapper sekcji */
.beauty-product{
  padding-top: 18px;
  padding-bottom: 52px;
}

/* papier */
.beauty-product .beauty-paper{
  border-radius: var(--hb-radius);
  background: var(--hb-paper);
  border: 1px solid rgba(0,0,0,.06);
  box-shadow: var(--hb-shadow);
  padding: 18px;
}

/* reset floatów Woo */
.beauty-single-wrap .product{
  margin: 0;
  display: grid;
  grid-template-columns: 1.05fr .95fr;
  gap: 18px;
}
.beauty-single-wrap .product .woocommerce-product-gallery,
.beauty-single-wrap .product .summary{
  float: none !important;
  width: auto !important;
}

/* notices */
.beauty-single-wrap .woocommerce-notices-wrapper{
  grid-column: 1 / -1;
  margin-bottom: 12px;
}
.woocommerce-message,
.woocommerce-info,
.woocommerce-error{
  border-radius: 14px;
  border: 1px solid rgba(0,0,0,.08);
  box-shadow: 0 10px 26px rgba(0,0,0,.10);
}

/* karty: galeria + summary */
.beauty-single-wrap .product .woocommerce-product-gallery,
.beauty-single-wrap .product .summary{
  background: var(--hb-paper-2);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: var(--hb-radius-2);
  padding: 16px;
}

/* ========== GALERIA ========== */
.beauty-single-wrap .woocommerce-product-gallery{
  overflow: hidden;
}
.beauty-single-wrap .woocommerce-product-gallery__wrapper{
  border-radius: 16px;
  overflow: hidden;
}
.beauty-single-wrap .woocommerce-product-gallery__image{
  border-radius: 16px;
  overflow: hidden;
}
.beauty-single-wrap .woocommerce-product-gallery__image img{
  width: 100%;
  height: auto;
  border-radius: 16px;
  display:block;
}

/* klik w obraz otwiera modal */
.beauty-single-wrap .woocommerce-product-gallery__image a{
  cursor: zoom-in;
}

/* miniatury */
.beauty-single-wrap .flex-control-thumbs{
  margin-top: 12px !important;
  display: grid !important;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}
.beauty-single-wrap .flex-control-thumbs li{ margin:0 !important; }
.beauty-single-wrap .flex-control-thumbs img{
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,.10);
  opacity: .88;
  transition: .18s ease;
}
.beauty-single-wrap .flex-control-thumbs img:hover{
  opacity: 1;
  transform: translateY(-1px);
}
.beauty-single-wrap .flex-control-thumbs .flex-active{
  outline: 2px solid rgba(31,90,58,.35);
  outline-offset: 2px;
  opacity: 1;
}

/* ========== SUMMARY ========== */
.beauty-single-wrap .product_title{
  font-size: clamp(22px, 2.1vw, 34px);
  line-height: 1.15;
  margin-bottom: 10px;
}

.beauty-single-wrap .woocommerce-product-rating{ margin: 6px 0 10px; }
.beauty-single-wrap .star-rating span::before{ color: var(--hb-gold); }

.beauty-single-wrap .price{
  font-size: 22px;
  font-weight: 700;
  margin: 10px 0 14px;
}

.beauty-single-wrap .woocommerce-product-details__short-description{
  margin: 10px 0 16px;
  color: rgba(0,0,0,.75);
}

/* form cart */
.beauty-single-wrap form.cart{
  display: grid;
  gap: 12px;
  margin-top: 10px;
}
.beauty-single-wrap .quantity{
  display: inline-flex;
  gap: 10px;
  align-items: center;
}
.beauty-single-wrap .quantity input.qty{
  width: 40px !important;
  max-width: 110px;
  height: 44px;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,.12);
  background: rgba(255,255,255,.9);
}
.beauty-single-wrap .single_add_to_cart_button{
  height: 48px;
  border-radius: 14px !important;
  border: 0 !important;
  font-weight: 700 !important;
  padding: 10px 18px !important;
  background: var(--hb-green) !important;
  color: #fff !important;
  box-shadow: var(--hb-shadow);
  transition: .18s ease;
}
.beauty-single-wrap .single_add_to_cart_button:hover{
  transform: translateY(-1px);
  filter: saturate(1.05);
}
.beauty-single-wrap .single_add_to_cart_button:disabled{
  opacity: .7 !important;
}

/* meta */
.beauty-single-wrap .product_meta{
  margin-top: 14px;
  padding-top: 14px;
  border-top: 1px solid rgba(0,0,0,.08);
  color: rgba(0,0,0,.70);
}
.beauty-single-wrap .product_meta a{
  color: var(--hb-green);
  text-decoration: none;
}
.beauty-single-wrap .product_meta a:hover{ text-decoration: underline; }

/* ========== TABS (opis/opinie/dodatkowe info) ========== */
.beauty-single-wrap .woocommerce-tabs{
  grid-column: 1 / -1;
  margin-top: 0;
  background: var(--hb-paper-2);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: var(--hb-radius-2);
  padding: 16px;
}

.beauty-single-wrap .woocommerce-tabs ul.tabs{
  margin: 0 0 14px !important;
  padding: 0 !important;
  border-bottom: 1px solid var(--hb-border) !important;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.beauty-single-wrap .woocommerce-tabs ul.tabs li{
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  background: transparent !important;
}
.beauty-single-wrap .woocommerce-tabs ul.tabs li a{
  display: inline-block;
  padding: 10px 14px;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,.10);
  color: rgba(0,0,0,.75);
  text-decoration: none;
  transition: .18s ease;
}
.beauty-single-wrap .woocommerce-tabs ul.tabs li.active a{
  background: rgba(31,90,58,.10);
  border-color: rgba(31,90,58,.25);
  color: var(--hb-green);
}
.beauty-single-wrap .woocommerce-tabs ul.tabs li a:hover{
  transform: translateY(-1px);
}

/* zawartość tabów */
.beauty-single-wrap .woocommerce-Tabs-panel{
  margin: 0 !important;
}
.beauty-single-wrap .woocommerce-Tabs-panel h2{
  font-size: 18px;
  margin: 0 0 10px;
}

/* ========== REVIEWS / KOMENTARZE ========== */
.beauty-single-wrap #reviews{
  display: grid;
  grid-template-columns: 1.15fr .85fr;
  gap: 18px;
  align-items: start;
}

.beauty-single-wrap #reviews #comments,
.beauty-single-wrap #reviews #review_form_wrapper{
  background: rgba(255,255,255,.55);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: 16px;
  padding: 14px;
}

/* lista opinii */
.beauty-single-wrap #reviews #comments h2{
  font-size: 18px;
  margin-bottom: 10px;
}
.beauty-single-wrap #reviews ol.commentlist{
  margin: 0 !important;
  padding: 0 !important;
  list-style: none !important;
  display: grid;
  gap: 12px;
}
.beauty-single-wrap #reviews ol.commentlist li{
  margin: 0 !important;
}
.beauty-single-wrap #reviews .comment_container{
  display: grid;
  grid-template-columns: 52px 1fr;
  gap: 12px;
  align-items: start;
  padding: 12px;
  border: 1px solid rgba(0,0,0,.08);
  border-radius: 14px;
  background: rgba(255,255,255,.75);
}
.beauty-single-wrap #reviews img.avatar{
  width: 52px !important;
  height: 52px !important;
  border-radius: 14px !important;
  margin: 0 !important;
  border: 1px solid rgba(0,0,0,.10);
}
.beauty-single-wrap #reviews .comment-text{
  margin: 0 !important;
  border: 0 !important;
  padding: 0 !important;
}
.beauty-single-wrap #reviews .comment-text .star-rating span::before{
  color: var(--hb-gold);
}
.beauty-single-wrap #reviews .comment-text p.meta{
  margin: 0 0 6px !important;
  color: rgba(0,0,0,.65);
}
.beauty-single-wrap #reviews .comment-text p{
  margin: 0;
  color: rgba(0,0,0,.78);
}

/* formularz opinii */
.beauty-single-wrap #reviews #review_form_wrapper h3{
  font-size: 18px;
  margin: 0 0 10px;
}
.beauty-single-wrap #reviews .comment-form{
  display: grid;
  gap: 12px;
}
.beauty-single-wrap #reviews .comment-form label{
  font-weight: 600;
  margin-bottom: 6px;
}
.beauty-single-wrap #reviews .comment-form input[type="text"],
.beauty-single-wrap #reviews .comment-form input[type="email"],
.beauty-single-wrap #reviews .comment-form textarea{
  width: 100%;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,.12);
  background: rgba(255,255,255,.9);
  padding: 10px 12px;
}
.beauty-single-wrap #reviews .comment-form textarea{
  min-height: 120px;
}
.beauty-single-wrap #reviews .form-submit input[type="submit"]{
  height: 46px;
  border-radius: 14px;
  border: 0;
  background: var(--hb-green);
  color: #fff;
  font-weight: 700;
  box-shadow: var(--hb-shadow);
  transition: .18s ease;
}
.beauty-single-wrap #reviews .form-submit input[type="submit"]:hover{
  transform: translateY(-1px);
}

/* gwiazdki wyboru w formularzu */
.beauty-single-wrap #reviews p.stars a{
  color: var(--hb-gold);
}
.beauty-single-wrap #reviews p.stars a:hover{
  color: var(--hb-gold);
}

/* ========== RELATED / UPSELLS ========== */
.beauty-single-wrap .related,
.beauty-single-wrap .upsells{
  grid-column: 1 / -1;
  margin-top: 16px;
  background: var(--hb-paper-2);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: var(--hb-radius-2);
  padding: 16px;
}
.beauty-single-wrap .related > h2,
.beauty-single-wrap .upsells > h2{
  font-size: 18px;
  margin: 0 0 12px;
}

/* ========== MODAL LIGHTBOX ========== */
.hb-product-modal .modal-dialog{ padding: 10px; }
.hb-product-modal .modal-content{
  background: rgba(4,18,10,.96);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 20px;
  overflow: hidden;
}
.hb-product-modal .modal-header{ border:0; padding: 10px 12px 0; }
.hb-product-modal .modal-body{ padding: 12px 12px 18px; }
.hb-product-modal .hb-slide{
  width: 100%;
  height: min(74vh, 760px);
  object-fit: contain;
  display: block;
  margin: 0 auto;
  background: rgba(0,0,0,.18);
  border-radius: 14px;
}
.hb-product-modal .carousel-control-prev,
.hb-product-modal .carousel-control-next{
  width: 10%;
  opacity: 1;
}
.hb-product-modal .carousel-control-prev-icon,
.hb-product-modal .carousel-control-next-icon{
  filter: drop-shadow(0 8px 18px rgba(0,0,0,.6));
}





/* ========== RESPONSYWNOŚĆ ========== */
@media (max-width: 992px){
  .beauty-product .beauty-paper{ padding: 14px; }
  .beauty-single-wrap .product{
    grid-template-columns: 1fr;
  }
  .beauty-single-wrap .product .woocommerce-product-gallery,
  .beauty-single-wrap .product .summary{
    padding: 14px;
  }
  .beauty-single-wrap .flex-control-thumbs{ grid-template-columns: repeat(4, 1fr); }

  .beauty-single-wrap #reviews{
    grid-template-columns: 1fr;
  }
}
@media (max-width: 576px){
  .beauty-single-wrap .flex-control-thumbs{ grid-template-columns: repeat(3, 1fr); }
  .beauty-single-wrap .quantity input.qty{ width: 92px !important; max-width: 92px; }
}
</style>


<!-- Product gallery modal (lightbox) -->
<div class="modal fade hb-product-modal" id="hbProductGalleryModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="modal" aria-label="Zamknij"></button>
      </div>
      <div class="modal-body">
        <div id="hbProductGalleryCarousel" class="carousel slide" data-bs-ride="false" data-bs-wrap="true">
          <div class="carousel-inner" id="hbProductGalleryCarouselInner"></div>

          <button class="carousel-control-prev" type="button" data-bs-target="#hbProductGalleryCarousel" data-bs-slide="prev" aria-label="Poprzednie">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#hbProductGalleryCarousel" data-bs-slide="next" aria-label="Następne">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- HERO -->
<header class="beauty-page-hero beauty-shop-hero beauty-product-hero">
  <div class="container">
    <div class="beauty-page-hero__inner">
      <h1 class="beauty-page-title"><?php the_title(); ?></h1>
      <div class="beauty-page-ornament" aria-hidden="true"></div>
    </div>
  </div>
</header>

<section class="beauty-product py-4 py-lg-5">
  <div class="container-fluid beauty-container-fluid">

    <?php do_action('woocommerce_before_main_content'); ?>

    <div class="beauty-paper">
      <?php while ( have_posts() ) : the_post(); ?>
        <div class="beauty-single-wrap">
          <?php wc_get_template_part('content', 'single-product'); ?>
        </div>
      <?php endwhile; ?>
    </div>

    <?php do_action('woocommerce_after_main_content'); ?>

  </div>
</section>

<script>
(function(){
  function hasBootstrap(){
    return !!(window.bootstrap && bootstrap.Modal && bootstrap.Carousel);
  }

  // 1) Lightbox: klik w główne zdjęcie lub miniaturę
  document.addEventListener('click', function(e){
    const a = e.target.closest('.woocommerce-product-gallery__image a, .flex-control-thumbs a');
    if(!a) return;

    // nie zepsuj standardowego zachowania jeśli brak BS
    if(!hasBootstrap()) return;

    e.preventDefault();

    // zbierz wszystkie linki do pełnych obrazów z galerii
    const gallery = document.querySelector('.woocommerce-product-gallery');
    if(!gallery) return;

    const links = Array.from(gallery.querySelectorAll('.woocommerce-product-gallery__image a'))
      .map(x => x.getAttribute('href'))
      .filter(Boolean);

    if(!links.length) return;

    const clickedHref = a.getAttribute('href') || '';
    let startIndex = Math.max(0, links.indexOf(clickedHref));
    if(startIndex < 0) startIndex = 0;

    const inner = document.getElementById('hbProductGalleryCarouselInner');
    inner.innerHTML = '';

    links.forEach((src, i) => {
      const item = document.createElement('div');
      item.className = 'carousel-item' + (i === startIndex ? ' active' : '');

      const img = document.createElement('img');
      img.className = 'hb-slide';
      img.src = src;
      img.alt = 'Zdjęcie ' + (i+1);

      item.appendChild(img);
      inner.appendChild(item);
    });

    const modalEl = document.getElementById('hbProductGalleryModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.show();

    const carouselEl = document.getElementById('hbProductGalleryCarousel');
    const carousel = bootstrap.Carousel.getOrCreateInstance(carouselEl, {
      interval: false,
      wrap: true,
      touch: true
    });

    // ustaw start po zbudowaniu slajdów
    setTimeout(() => carousel.to(startIndex), 0);
  });

  // 2) UX: po dodaniu do koszyka przewiń do notices
  document.addEventListener('click', function(e){
    const btn = e.target.closest('.single_add_to_cart_button');
    if(!btn) return;
    setTimeout(function(){
      const notices = document.querySelector('.woocommerce-notices-wrapper');
      if(notices) notices.scrollIntoView({behavior:'smooth', block:'start'});
    }, 450);
  });
})();
</script>

<?php get_footer('shop'); ?>