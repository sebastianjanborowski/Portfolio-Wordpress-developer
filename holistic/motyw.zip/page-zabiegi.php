<?php
/**
 * Template Name: Kontakt
 */
defined('ABSPATH') || exit;

get_header();

$img_path = trailingslashit(get_template_directory_uri()) . 'assets/img/galeria/';

$zabiegi = [
    [
        'title' => 'Indywidualne Konsultacje i Spersonalizowany Skin Plan',
        'badge' => 'Konsultacja',
        'image' => $img_path . '1-zabiegi.jpg',
        'content' => [
            'Twoja skóra jest unikalna, dlatego każdą drogę do piękna w naszym gabinecie zaczynamy od rozmowy i wnikliwej diagnozy.',
            'Zapraszamy Cię na profesjonalną konsultację, podczas której wspólnie przeanalizujemy potrzeby Twojej cery, styl życia oraz dotychczasową pielęgnację domową.',
            'Bezpośrednio po diagnozie wykonujemy profesjonalny zabieg dopasowany do aktualnych potrzeb Twojej skóry, abyś mogła od razu poczuć różnicę.',
            'Na zakończenie spotkania wspólnie stworzymy Twój spersonalizowany Skin Plan – doradzimy Ci, jakie terapie gabinetowe będą najskuteczniejsze i jak dbać o skórę w domu, by efekty naszej pracy cieszyły Cię jak najdłużej.',
        ],
        'price_title' => 'Cena',
        'price' => 'od 350 zł',
        'price_desc' => 'Ostateczna cena zabiegu ustalana jest podczas indywidualnej konsultacji, w zależności od potrzeb Twojej skóry i dobranego preparatu.',
        'link' => '#',
    ],
    [
        'title' => 'Endermologia LPG – Modelowanie Sylwetki i Redukcja Cellulitu',
        'badge' => 'Sylwetka',
        'image' => $img_path . 'zabiegi-2.jpg',
        'content' => [
            'Odkryj potęgę bezinwazyjnego modelowania sylwetki dzięki światowemu liderowi – technologii Endermologie LPG Alliance.',
            'Zabieg ten naturalnie pobudza metabolizm tkanek, skutecznie redukując tkankę tłuszczową, wygładzając cellulit i ujędrniając skórę.',
            'Dzięki unikalnej stymulacji tkanki redukuje obrzęki limfatyczne, niweluje napięcia mięśni oraz wspomagania regeneracje po zabiegach chirurgicznych.',
            'To idealne rozwiązanie dla osób pragnących wymodelować ciało na wakacje i poczuć się lekko oraz zdrowo w swojej skórze.',
        ],
        'price_title' => 'Inwestycja w Twoją Sylwetkę',
        'price' => '190 zł – 300 zł / pakiet 1400 zł – 2300 zł',
        'price_desc' => 'Pojedynczy zabieg twarz lub ciało: 190 zł – 300 zł. Cena zależy od czasu trwania oraz obszaru zabiegowego. Kostium do endermologii Endermowear: 80 zł. Własny strój jest niezbędny do zachowania higieny i komfortu podczas zabiegu. Pakiet 10 zabiegów: 1400 zł – 2300 zł.',
        'link' => '#',
    ],
    [
        'title' => 'Zaawansowana Rewitalizacja i Anti-Aging',
        'badge' => 'Anti-aging',
        'image' => $img_path . 'zabiegi-3.jpg',
        'content' => [
            'Skupiamy się na inteligentnym odmładzaniu, które pobudza naturalne procesy naprawcze Twojej skóry.',
            'Wykorzystujemy najwyższej klasy preparaty, w tym cenione linie DIVES Med, aby dostarczyć tkankom dokładnie tego, czego potrzebują do głębokiej regeneracji.',
            'Stymulatory tkankowe, np. 7-V-LIFT: To nowoczesne preparaty, które dają sygnał Twojej skórze do produkcji nowego kolagenu i elastyny. Działają one bezpośrednio na strukturę skóry, powodując wyraźne wygładzenie zmarszczek, przywrócenie gęstości oraz naturalny efekt liftingu bez zmiany rysów twarzy.',
            'Mezoterapia igłowa: Zabieg polegający na precyzyjnym dostarczeniu koktajlu witamin, aminokwasów i kwasu hialuronowego. Błyskawicznie redukuje drobne linie, intensywnie nawilża i napina cerę, przywracając jej świeży, młodzieńczy wygląd i aksamitną gładkość.',
            'Przy zabiegach iniekcyjnych, takich jak mezoterapia czy stymulatory, rezygnacja z sztywnych pakietów na stronie jest bardzo profesjonalnym ruchem. Podkreśla to, że każdy zabieg jest dobierany indywidualnie do stanu skóry w danym dniu, a nie sprzedawany hurtowo.',
        ],
        'price_title' => 'Inwestycja w Młodą i Zdrową Skórę',
        'price' => '400 zł – 1200 zł',
        'price_desc' => 'Ceny zabiegów iniekcyjnych zależą od rodzaju wybranego preparatu, jego ilości oraz obszaru podania: twarz, szyja, dekolt lub okolica oczu. Dokładny koszt terapii ustalany jest podczas konsultacji, aby idealnie dopasować produkt do potrzeb Twojej cery. Mezoterapia Igłowa: 400 zł – 750 zł. Stymulatory Tkankowe: 700 zł – 1200 zł. W przypadku stymulatorów tkankowych i mezoterapii, dla uzyskania długotrwałego efektu wygładzenia i napięcia, zazwyczaj zaleca się wykonanie serii 2–4 zabiegów w odstępach kilku tygodni.',
        'link' => '#',
    ],
    [
        'title' => 'Thermo-lifting RF Mikroigłowa — Lifting bez skalpela',
        'badge' => 'Lifting',
        'image' => trailingslashit(get_template_directory_uri()) . 'assets/img/placeholder-zabieg.jpg',
        'content' => [
            'To zaawansowany zabieg anti-aging, który pozwala uzyskać spektakularny efekt napięcia i zagęszczenia skóry bez użycia skalpela.',
            'Wykorzystujemy technologię radiofrekwencji RF, która poprzez kontrolowane rozgrzanie tkanek stymuluje fibroblasty do produkcji nowego kolagenu i elastyny.',
            'Efektem jest wyraźne podniesienie owalu twarzy i redukcja wiotkości.',
            'Zabieg jest nieinwazyjny, nie wymaga okresu rekonwalescencji i idealnie sprawdza się u osób pragnących wygładzenia zmarszczek oraz naturalnego efektu odmłodzenia.',
        ],
        'price_title' => 'Inwestycja w Jędrność i Nowy Owal Twarzy',
        'price' => '800 zł – 1200 zł',
        'price_desc' => 'Koszt zabiegu Thermo-liftingu zależy od wielkości obszaru poddawanego regeneracji oraz intensywności terapii. Każdy zabieg obejmuje profesjonalne przygotowanie skóry oraz wykończenie kojącymi preparatami pozabiegowymi. Choć efekt napięcia włókien kolagenowych jest widoczny często już po pierwszym zabiegu, dla uzyskania trwałej przebudowy skóry i długofalowego efektu baby face, zalecamy wykonanie serii 3–4 spotkań.',
        'link' => '#',
    ],
    [
        'title' => 'Trwała Depilacja Laserowa Vectus',
        'badge' => 'Depilacja',
        'image' => $img_path . 'zabiegi-5.jpg',
        'content' => [
            'Pożegnaj problem niechcianego owłosienia raz na zawsze dzięki najszybszemu i najbezpieczniejszemu laserowi diodowemu na świecie – Vectus.',
            'Wyposażony w inteligentny czytnik poziomu melaniny Skintel™, urządzenie precyzyjnie dobiera parametry do Twojej karnacji, gwarantując maksymalną skuteczność i komfort.',
            'Duża głowica zabiegowa wyposażona w zaawansowany system chłodzenia sprawia, że procedura jest niezwykle szybka i komfortowa nawet na wrażliwych obszarach ciała.',
            'To inwestycja w aksamitnie gładką skórę, która pozwoli Ci cieszyć się swobodą w każdej sytuacji.',
            'Planujesz już letnie wyjazdy? Rozpocznij serię zabiegów już teraz, aby podczas wakacji cieszyć się nieskazitelnie gładką skórą i całkowitą wolnością od codziennej depilacji czy podrażnień po maszynce.',
        ],
        'price_title' => 'Inwestycja w Gładką Skórę bez Kompromisów',
        'price' => '190 zł – 730 zł',
        'price_desc' => 'Cena zabiegu laserowego Vectus zależy od liczby depilowanych partii ciała podczas jednej wizyty. Stawiamy na zasadę: im więcej partii wybierzesz, tym niższa cena jednostkowa za każdą z nich. Od 1 partii – 190 zł do 7 partii – 730 zł.',
        'link' => '#',
    ],
    [
        'title' => 'Terapie Oczyszczające i Odżywcze — Pielęgnacja Twarzy',
        'badge' => 'Twarz',
        'image' => $img_path . 'zabiegi-6.jpg',
        'content' => [
            'Fundamentem każdej skutecznej pielęgnacji jest idealnie oczyszczona i dotleniona skóra.',
            'W tej grupie oferujemy zabiegi, które błyskawicznie przywracają twarzy świeżość, eliminują niedoskonałości i dostarczają skoncentrowanych składników aktywnych.',
            'Oczyszczanie wodorowe: Innowacyjna technologia, która wykorzystuje cząsteczki aktywnego wodoru do głębokiego oczyszczenia porów i walki z wolnymi rodnikami. To idealny detoks, który pozostawia skórę idealnie gładką i przygotowaną na dalsze kroki pielęgnacyjne.',
            'Terapie z witaminą C: Prawdziwy zastrzyk energii dla poszarzałej i zmęczonej cery. Wysokie stężenie witaminy C działa silnie antyoksydacyjnie, uszczelnia naczynka i wyrównuje koloryt, nadając twarzy natychmiastowy blask i wypoczęty wygląd.',
            'Zabiegi łagodzące i nawilżające, np. z witaminą U: Wykorzystujemy unikalną witaminę U, znaną ze swoich niezwykłych właściwości regenerujących i kojących. To ratunek dla skór wrażliwych, naczyniowych i skłonnych do podrażnień.',
            'Peeling kawitacyjny i maski terapeutyczne: Bezbolesne oczyszczanie ultradźwiękami, które w połączeniu z profesjonalnymi ampułkami i maskami algowymi dopasowujemy precyzyjnie do aktualnego stanu Twojej cery.',
        ],
        'price_title' => 'Czas na Blask i Odświeżenie',
        'price' => '100 zł – 420 zł',
        'price_desc' => 'Podstawą pięknej cery jest jej regularne oczyszczanie i głębokie odżywienie. Cena zabiegu zależy od wybranego wariantu terapii – od ekspresowego odświeżenia wodorowego, po rozbudowane rytuały witaminowe z użyciem ampułek i masek algowych.',
        'link' => '#',
    ],
    [
        'title' => 'Zaawansowane Peelingi i Kwasy',
        'badge' => 'Peelingi',
        'image' => $img_path . 'zabiegi-7.jpg',
        'content' => [
            'W naszym gabinecie stawiamy na bezpieczną i skuteczną odnowę skóry poprzez indywidualnie dobrane terapie kwasowe.',
            'Pracujemy na certyfikowanych preparatach medycznych światowych marek, takich jak DIVES Med, BioRePeelCl3 czy PRX-T33, które pozwalają na osiągnięcie spektakularnych efektów bez długotrwałego złuszczania naskórka.',
            'Peelingi całoroczne, np. BioRePeel, PRX-T33: Innowacyjne formuły, które intensywnie stymulują skórę do odnowy, napinają ją i rozświetlają, nie powodując przy tym silnego podrażnienia – idealne jako zabiegi bankietowe.',
            'Terapie kwasowe celowane: Wykorzystujemy szeroki wachlarz kwasów, m.in. migdałowy, salicylowy, glikolowy czy laktobionowy, które precyzyjnie uderzają w konkretne problemy: od trądziku i rozszerzonych porów, po przebarwienia i pierwsze oznaki starzenia.',
            'Zabiegi z witaminą C i retinolem: Silne protokoły złuszczające i rozjaśniające, które wyrównują strukturę skóry, wygładzają drobne zmarszczki i przywracają cerze zdrowy, jednolity koloryt.',
        ],
        'price_title' => 'Twój Plan na Promienną Cerę',
        'price' => '350 zł – 600 zł',
        'price_desc' => 'Cena zabiegu z wykorzystaniem peelingów chemicznych zależy od wybranego preparatu oraz stopnia zaawansowania terapii. Każdy protokół dobieramy indywidualnie po analizie potrzeb Twojej skóry – od delikatnego odświeżenia, po intensywną przebudowę struktury naskórka.',
        'link' => '#',
    ],
    [
        'title' => 'Holistyczne Rytuały i Masaże — Balans Duszy i Ciała',
        'badge' => 'Relaks',
        'image' => $img_path . 'zabiegi-8.jpg',
        'content' => [
            'Wierzymy, że prawdziwe piękno rodzi się z wewnętrznego spokoju.',
            'Nasze rytuały to połączenie mistrzowskich technik manualnych z głęboką pracą nad energią i wyciszeniem umysłu, co pozwala na całkowitą regenerację organizmu.',
            'Japoński Masaż Kobido: Nazywany niechirurgicznym liftingiem twarzy. To intensywna terapia manualna, która niweluje napięcia mięśniowe, poprawia owal twarzy i wygładza zmarszczki, dając efekt naturalnego odmłodzenia.',
            'Zabieg ten intensywnie stymuluje produkcję kolagenu i elastyny oraz dzięki elementom drenażu limfatycznego usuwa toksyny i obrzęki, przywracając twarzy świeżość oraz naturalny, młodzieńczy blask.',
            'Access Bars: Energetyczny proces manualny, polegający na delikatnym dotyku 32 punktów na głowie. Zabieg ten pozwala na głębokie rozładowanie stresu, uwolnienie od natłoku myśli i ograniczeń, otwierając przestrzeń na nowe możliwości i spokój w każdej dziedzinie życia.',
            'Bioenergioterapia i Wspólna Medytacja: Wyjątkowe sesje wspierające naturalne procesy samoregulacji organizmu. Praca z energią i prowadzona medytacja pomagają uwolnić skumulowane emocje, odzyskać wewnętrzną równowagę i poczucie harmonii.',
            'Masaże Relaksacyjne: Klasyczne techniki odprężające, które przynoszą ulgę zmęczonym mięśniom i koją zmysły. Idealny wybór, by odciąć się od codziennego pośpiechu i podarować sobie chwilę zasłużonego wytchnienia.',
        ],
        'price_title' => 'Podaruj Sobie Chwilę Wytchnienia',
        'price' => '220 zł – 300 zł',
        'price_desc' => 'Nasze rytuały to coś więcej niż pielęgnacja – to czas zatrzymania, regeneracji i głębokiego kontaktu ze sobą. Cena każdego spotkania obejmuje pełne przygotowanie przestrzeni, aromaterapię oraz indywidualne podejście do Twoich potrzeb energetycznych i mięśniowych.',
        'link' => '#',
    ],
];
?>

<main class="beauty-contact">
    <section class="beauty-treatments py-5">
        <div class="container py-lg-4">

            <header class="row justify-content-center text-center mb-5">
                <div class="col-12">
                    <div class="d-flex align-items-center justify-content-center gap-3 mb-3">
                        <span class="beauty-line d-inline-block"></span>
                        <span class="text-uppercase fw-bold small beauty-gold">Oferta gabinetu</span>
                        <span class="beauty-line d-inline-block"></span>
                    </div>

                    <h1 class="display-5 fw-bold mb-3 beauty-green">
                        Zabiegi dopasowane do Twoich potrzeb
                    </h1>

                    <p class="lead text-muted mb-0">
                        Wybierz zabieg i zarezerwuj termin. Ostateczny plan terapii dobieramy indywidualnie po analizie skóry i potrzeb.
                    </p>
                </div>
            </header>

            <div class="row g-4 justify-content-center">
                <?php foreach ($zabiegi as $index => $zabieg) :

                    $title       = $zabieg['title'] ?? '';
                    $badge       = $zabieg['badge'] ?? '';
                    $image       = $zabieg['image'] ?? '';
                    $content     = $zabieg['content'] ?? [];
                    $price_title = $zabieg['price_title'] ?? '';
                    $price       = $zabieg['price'] ?? '';
                    $price_desc  = $zabieg['price_desc'] ?? '';
                    $link        = $zabieg['link'] ?? '#';

                    $is_first = $index === 0;
                ?>
                    <div class="col-12 col-md-6">
                        <article class="card h-100 border-0 rounded-4 shadow-sm overflow-hidden treatment-card">

                            <?php if ($image) : ?>
                                <div class="ratio ratio-16x9 bg-secondary bg-opacity-10">
                                    <img
                                        src="<?php echo esc_url($image); ?>"
                                        alt="<?php echo esc_attr($title); ?>"
                                        class="w-100 h-100 object-fit-cover"
                                        width="800"
                                        height="450"
                                        decoding="async"
                                        loading="<?php echo $is_first ? 'eager' : 'lazy'; ?>"
                                        fetchpriority="<?php echo $is_first ? 'high' : 'auto'; ?>"
                                    >
                                </div>
                            <?php endif; ?>

                            <div class="card-body d-flex flex-column p-4">

                                <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                                    <?php if ($badge) : ?>
                                        <span class="badge rounded-pill bg-light text-secondary border px-3 py-2">
                                            <?php echo esc_html($badge); ?>
                                        </span>
                                    <?php endif; ?>

                                    <span class="small text-muted fw-bold">
                                        <?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?>
                                    </span>
                                </div>

                                <?php if ($title) : ?>
                                    <h2 class="h4 fw-bold lh-sm mb-3">
                                        <?php echo esc_html($title); ?>
                                    </h2>
                                <?php endif; ?>

                                <?php if (!empty($content)) : ?>
                                    <div class="text-muted small lh-lg mb-4">
                                        <?php foreach ($content as $paragraph) : ?>
                                            <p class="mb-3">
                                                <?php echo esc_html($paragraph); ?>
                                            </p>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="mt-auto pt-4 border-top">

                                    <?php if ($price_title) : ?>
                                        <p class="small text-uppercase fw-bold text-muted mb-2">
                                            <?php echo esc_html($price_title); ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if ($price) : ?>
                                        <p class="h5 fw-bold beauty-green mb-3">
                                            <?php echo esc_html($price); ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if ($price_desc) : ?>
                                        <p class="small text-muted lh-lg mb-4">
                                            <?php echo esc_html($price_desc); ?>
                                        </p>
                                    <?php endif; ?>

                                    <a href="<?php echo esc_url($link); ?>" class="btn w-100 rounded-pill fw-semibold px-4 py-3 holistic-zabiegi-button">
                                        Zarezerwuj termin
                                    </a>

                                </div>

                            </div>
                        </article>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
    </section>
</main>

<style>
.beauty-treatments{
    background:
        radial-gradient(circle at top left, rgba(212,184,93,.14), transparent 34%),
        linear-gradient(180deg,#f8faf9 0%,#fff 100%);
}

.beauty-green{
    color:#1f5f52!important;
}

.beauty-gold{
    color:#d4b85d!important;
    letter-spacing:.16em;
}

.beauty-line{
    width:42px;
    height:1px;
    background:#d4b85d;
    opacity:.75;
}

.treatment-card{
    border:1px solid rgba(31,95,82,.08)!important;
    box-shadow:0 14px 40px rgba(31,95,82,.08)!important;
    transition:transform .25s ease,box-shadow .25s ease,border-color .25s ease;
}

.treatment-card:hover{
    transform:translateY(-6px);
    border-color:rgba(212,184,93,.45)!important;
    box-shadow:0 24px 70px rgba(31,95,82,.15)!important;
}

.holistic-zabiegi-button{
    background:#1f5f52;
    border:1px solid #1f5f52;
    color:#fff!important;
    box-shadow:0 8px 20px rgba(31,95,82,.18);
    transition:background-color .22s ease,border-color .22s ease,color .22s ease,transform .22s ease;
}

.holistic-zabiegi-button:hover{
    background:var(--kolor-tla-przycisk-zloty,#d4b85d);
    border-color:var(--kolor-tla-przycisk-zloty,#d4b85d);
    color:var(--bg-soft,#1f332e)!important;
    transform:translateY(-2px);
}

@media (max-width:767.98px){
    .beauty-line{
        width:24px;
    }
}
</style>

<?php get_footer(); ?>